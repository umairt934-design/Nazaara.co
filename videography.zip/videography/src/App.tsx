import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Experience from './components/Experience';
import Deliverables from './components/Deliverables';
import Process from './components/Process';
import Footer from './components/Footer';
import FloatingCTA from './components/FloatingCTA';

// Lazy load pages for better performance
const About = lazy(() => import('./components/About'));
const Blog = lazy(() => import('./components/Blog'));
const FAQs = lazy(() => import('./components/FAQs'));

function Home() {
  return (
    <>
      <Hero />
      <Experience />
      <Deliverables />
      <Process />
    </>
  );
}

// Loading component for better UX
function LoadingSpinner() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-soft-linen">
      <div className="text-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-tan"></div>
        <p className="mt-4 text-stone-brown">Loading...</p>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen w-full">
        <Navigation />
        <FloatingCTA />
        <Suspense fallback={<LoadingSpinner />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/about" element={<About />} />
            <Route path="/faqs" element={<FAQs />} />
          </Routes>
        </Suspense>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
