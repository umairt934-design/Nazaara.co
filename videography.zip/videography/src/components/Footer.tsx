import { Link } from 'react-router-dom';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import logo from '../assets/Nazaara logo transparent background.png';

export default function Footer() {
  const { ref, isVisible } = useScrollAnimation();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      ref={ref as React.RefObject<HTMLElement>}
      className={`bg-black text-soft-linen py-12 px-4 sm:px-6 lg:px-8 transition-all duration-1000 overflow-x-hidden ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 mb-6 sm:mb-8">
          <div>
            <img src={logo} alt="Nazara" className="h-28 sm:h-12 mb-3 sm:mb-4 brightness-0 invert" />
            <p className="text-xs sm:text-sm leading-relaxed">
              Creating and editing videos that communicate the correct message
              every time.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">Quick Links</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <Link to="/" onClick={scrollToTop} className="hover:text-tan transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/blog" onClick={scrollToTop} className="hover:text-tan transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/about" onClick={scrollToTop} className="hover:text-tan transition-colors">
                  About
                </Link>
              </li>
              <li>
                <a
                  href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-tan transition-colors"
                >
                  Contact
                </a>
              </li>
              <li>
                <Link to="/faqs" onClick={scrollToTop} className="hover:text-tan transition-colors">
                  FAQs
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">Get in Touch</h4>
            <a
              href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-tan text-black px-4 sm:px-6 py-2 sm:py-3 text-xs sm:text-sm font-semibold hover:bg-stone-brown hover:text-soft-linen transition-all duration-300 w-full md:w-auto rounded text-center"
            >
              Book a Discovery Call
            </a>
          </div>
        </div>

        <div className="border-t border-stone-brown pt-6 sm:pt-8 text-center text-xs sm:text-sm">
          <p>&copy; 2025 Nazaara. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
