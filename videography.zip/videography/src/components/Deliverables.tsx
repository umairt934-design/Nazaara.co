import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Play } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const videos = [
  {
    id: 1,
    thumbnail: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Team Collaboration',
  },
  {
    id: 2,
    thumbnail: 'https://images.pexels.com/photos/7647066/pexels-photo-7647066.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Professional Interview',
  },
  {
    id: 3,
    thumbnail: 'https://images.pexels.com/photos/3760607/pexels-photo-3760607.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Corporate Event',
  },
  {
    id: 4,
    thumbnail: 'https://images.pexels.com/photos/3153201/pexels-photo-3153201.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Product Launch',
  },
  {
    id: 5,
    thumbnail: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Brand Story',
  },
  {
    id: 6,
    thumbnail: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Behind the Scenes',
  },
];

export default function Deliverables() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { ref, isVisible } = useScrollAnimation();
  const [isMobile, setIsMobile] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Detect mobile screen
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const videosPerPage = isMobile ? 1 : 3;

  const nextSlide = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentIndex((prev) => (prev + videosPerPage >= videos.length ? 0 : prev + videosPerPage));
    setTimeout(() => setIsTransitioning(false), 500);
  };

  const prevSlide = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentIndex((prev) => (prev - videosPerPage < 0 ? Math.max(0, videos.length - videosPerPage) : prev - videosPerPage));
    setTimeout(() => setIsTransitioning(false), 500);
  };

  const visibleVideos = videos.slice(currentIndex, currentIndex + videosPerPage);

  return (
    <section
      ref={ref as React.RefObject<HTMLElement>}
      className={`py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-black text-soft-linen transition-all duration-1000 overflow-x-hidden ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-3 sm:mb-4">
            The Deliverables
          </h2>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl px-4">
            This is just some of our previous client work
          </p>
        </div>

        <div className="relative max-w-6xl mx-auto">
          {/* Left Arrow - Always on the side */}
          <button
            onClick={prevSlide}
            disabled={currentIndex === 0}
            className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-stone-brown hover:bg-tan transition-all duration-300 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:scale-110 active:scale-95"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-soft-linen transition-transform duration-300" />
          </button>

          {/* Right Arrow - Always on the side */}
          <button
            onClick={nextSlide}
            disabled={currentIndex + videosPerPage >= videos.length}
            className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-stone-brown hover:bg-tan transition-all duration-300 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:scale-110 active:scale-95"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-soft-linen transition-transform duration-300" />
          </button>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8 px-16 md:px-20">
            {visibleVideos.map((video, index) => (
              <div
                key={video.id}
                className="relative bg-jet-black rounded-lg overflow-hidden group animate-fadeInSlide"
                style={{
                  aspectRatio: '16/12',
                  animationDelay: `${index * 100}ms`
                }}
              >
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-30 group-hover:bg-opacity-40 transition-all duration-300">
                  <button className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-tan hover:bg-stone-brown transition-all duration-300 flex items-center justify-center mb-3 transform hover:scale-110">
                    <Play className="w-6 h-6 sm:w-8 sm:h-8 text-black fill-black ml-1" />
                  </button>
                  <p className="text-sm sm:text-base font-semibold">{video.title}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Dots indicator */}
          <div className="flex justify-center gap-2">
            {Array.from({ length: Math.ceil(videos.length / videosPerPage) }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index * videosPerPage)}
                className={`w-2 h-2 rounded-full transition-all ${
                  currentIndex === index * videosPerPage ? 'bg-tan w-6 sm:w-8' : 'bg-stone-brown'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
