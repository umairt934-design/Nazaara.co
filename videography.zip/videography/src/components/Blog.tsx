import { useState, useEffect } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface BlogPost {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  date: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'Cinematic Storytelling in Brand Videos',
    description: 'Discover how we craft compelling narratives that resonate with audiences and elevate brand identity through cinematic techniques and emotional storytelling.',
    imageUrl: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&q=80',
    category: 'Videography',
    date: 'March 15, 2024',
  },
  {
    id: 2,
    title: 'Behind the Scenes: Corporate Video Production',
    description: 'An inside look at our production process, from pre-production planning to final delivery, showcasing the dedication and expertise behind every project.',
    imageUrl: 'https://images.unsplash.com/photo-1579389083078-4e7018379f7e?w=800&q=80',
    category: 'Production',
    date: 'March 10, 2024',
  },
  {
    id: 3,
    title: 'The Power of Visual Content Marketing',
    description: 'Learn how video content drives engagement and converts viewers into customers in today\'s digital landscape with proven strategies and insights.',
    imageUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&q=80',
    category: 'Marketing',
    date: 'March 5, 2024',
  },
  {
    id: 4,
    title: 'Essential Equipment for Professional Videos',
    description: 'A comprehensive guide to the cameras, lenses, and gear we use to create stunning professional video content that stands out.',
    imageUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&q=80',
    category: 'Equipment',
    date: 'February 28, 2024',
  },
  {
    id: 5,
    title: 'Color Grading: Transforming Your Footage',
    description: 'Explore the art of color grading and how it transforms raw footage into visually stunning content that captures attention and emotion.',
    imageUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&q=80',
    category: 'Post-Production',
    date: 'February 20, 2024',
  },
  {
    id: 6,
    title: 'Tips for Creating Engaging Social Media Videos',
    description: 'Master the art of creating short-form video content that captures attention, drives engagement, and builds your brand presence on social platforms.',
    imageUrl: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=800&q=80',
    category: 'Social Media',
    date: 'February 15, 2024',
  },
];

export default function Blog() {
  const { ref, isVisible } = useScrollAnimation();
  const [currentPage, setCurrentPage] = useState(1);
  const [isMobile, setIsMobile] = useState(false);
  const itemsPerPage = 5;

  // Check if mobile
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Calculate pagination
  const totalPages = Math.ceil(blogPosts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentBlogs = isMobile
    ? blogPosts.slice(startIndex, endIndex)
    : blogPosts;

  const goToPage = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="bg-black min-h-screen pt-20 md:pt-28">
      {/* Hero Section */}
      <section className="bg-black py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl font-bold text-soft-linen mb-6">
            Our Blog
          </h1>
          <p className="text-xl text-tan max-w-3xl mx-auto">
            Insights, tips, and stories from the world of videography and content creation
          </p>
        </div>
      </section>

      {/* Blog Posts Section */}
      <section
        ref={ref as React.RefObject<HTMLElement>}
        className={`py-12 px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="max-w-7xl mx-auto">
          {/* Blog Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentBlogs.map((blog) => (
              <article
                key={blog.id}
                className="group bg-stone-brown rounded-lg overflow-hidden shadow-2xl transform transition-all duration-500 hover:scale-105"
              >
                {/* Blog Image */}
                <div className="relative w-full h-[250px] md:h-[300px] overflow-hidden">
                  <img
                    src={blog.imageUrl}
                    alt={blog.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-tan text-black px-3 py-1 text-xs font-semibold rounded-full">
                      {blog.category}
                    </span>
                  </div>
                </div>

                {/* Blog Content */}
                <div className="p-4 md:p-6 bg-black">
                  <p className="text-tan text-xs md:text-sm mb-2">{blog.date}</p>
                  <h3 className="text-soft-linen text-lg md:text-xl font-bold mb-3 group-hover:text-tan transition-colors duration-300">
                    {blog.title}
                  </h3>
                  <p className="text-tan text-sm md:text-base line-clamp-3 mb-4">
                    {blog.description}
                  </p>
                  <button className="text-soft-linen text-sm font-semibold hover:text-tan transition-colors duration-300 flex items-center gap-2">
                    Read More
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>

          {/* Mobile Pagination */}
          {isMobile && totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 mt-8">
              <button
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage === 1}
                className="p-2 bg-tan hover:bg-stone-brown text-black rounded-full transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Previous page"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {Array.from({ length: totalPages }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToPage(index + 1)}
                  className={`w-10 h-10 rounded-full font-semibold transition-all duration-300 ${
                    currentPage === index + 1
                      ? 'bg-tan text-black'
                      : 'bg-stone-brown/50 text-soft-linen hover:bg-stone-brown'
                  }`}
                  aria-label={`Go to page ${index + 1}`}
                >
                  {index + 1}
                </button>
              ))}

              <button
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="p-2 bg-tan hover:bg-stone-brown text-black rounded-full transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Next page"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-stone-brown">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading text-4xl sm:text-5xl font-bold text-soft-linen mb-6">
            Ready to Create Your Story?
          </h2>
          <p className="text-xl text-tan mb-8">
            Let's produce amazing video content for your brand
          </p>
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-tan text-black px-8 py-4 text-lg font-semibold hover:bg-soft-linen transition-all duration-300 rounded shadow-lg hover:shadow-2xl transform hover:scale-105"
          >
            Get in Touch
          </a>
        </div>
      </section>
    </div>
  );
}
