import {
  Phone,
  Wallet,
  Camera,
  Image,
  Folder,
  Star,
} from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const steps = [
  {
    icon: Phone,
    step: 'Step 1. Book a call',
    description:
      'Every project starts with a discovery call and we will provide you with a proposal',
    color: 'text-blue-500',
    bgColor: 'bg-blue-100',
  },
  {
    icon: Wallet,
    step: 'Step 2. Lock in date',
    description:
      'When the proposal has been accepted we can lock in a shooting date with a deposit',
    color: 'text-green-500',
    bgColor: 'bg-green-100',
  },
  {
    icon: Camera,
    step: 'Step 3. Media day',
    description:
      'On your media day we will show up and capture all your content set out in the media day brief',
    color: 'text-purple-500',
    bgColor: 'bg-purple-100',
  },
  {
    icon: Image,
    step: 'Step 4. Editing',
    description:
      'We edit all your content for you so you can continue working on your business',
    color: 'text-orange-500',
    bgColor: 'bg-orange-100',
  },
  {
    icon: Folder,
    step: 'Step 5. Delivery',
    description:
      'We deliver all the content within 1 week of the shoot via google drive link or USB drive',
    color: 'text-pink-500',
    bgColor: 'bg-pink-100',
  },
  {
    icon: Star,
    step: 'Step 6. Review',
    description:
      'We are always looking at improving our service and would love feedback',
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100',
  },
];

export default function Process() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section
      ref={ref as React.RefObject<HTMLElement>}
      className={`py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-soft-linen transition-all duration-1000 overflow-x-hidden ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12 sm:mb-16 md:mb-24">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-3 sm:mb-4">
            The process
          </h2>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-stone-brown px-4">
            The easiest 6-step process for your content
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 md:gap-12">
          {steps.map((item, index) => (
            <div key={index} className="text-center px-2">
              <div className={`inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 mb-4 sm:mb-6 ${item.bgColor} rounded-lg shadow-lg`}>
                <item.icon className={`w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 ${item.color}`} strokeWidth={2} />
              </div>
              <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4">
                {item.step}
              </h3>
              <p className="text-xs sm:text-sm md:text-base leading-relaxed text-stone-brown">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
