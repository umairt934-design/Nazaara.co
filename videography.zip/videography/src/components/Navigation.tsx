import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import logo from '../assets/Nazaara logo transparent background.png';

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-jet-black/80 backdrop-blur-md text-soft-linen border-b border-stone-brown/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link to="/" onClick={scrollToTop} className="flex items-center">
            <img src={logo} alt="Nazara" className="h-20 md:h-28" />
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" onClick={scrollToTop} className="hover:text-tan transition-colors">
              Home
            </Link>
            <Link to="/blog" onClick={scrollToTop} className="hover:text-tan transition-colors">
              Blog
            </Link>
            <Link to="/about" onClick={scrollToTop} className="hover:text-tan transition-colors">
              About
            </Link>
            <a
              href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-tan transition-colors"
            >
              Contact
            </a>
            <Link to="/faqs" onClick={scrollToTop} className="hover:text-tan transition-colors">
              FAQs
            </Link>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-soft-linen"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-jet-black/95 backdrop-blur-md border-t border-stone-brown">
          <div className="px-4 py-4 space-y-4">
            <Link
              to="/"
              onClick={() => {
                setIsOpen(false);
                scrollToTop();
              }}
              className="block hover:text-tan transition-colors"
            >
              Home
            </Link>
            <Link
              to="/blog"
              onClick={() => {
                setIsOpen(false);
                scrollToTop();
              }}
              className="block hover:text-tan transition-colors"
            >
              Blog
            </Link>
            <Link
              to="/about"
              onClick={() => {
                setIsOpen(false);
                scrollToTop();
              }}
              className="block hover:text-tan transition-colors"
            >
              About
            </Link>
            <a
              href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
              target="_blank"
              rel="noopener noreferrer"
              className="block hover:text-tan transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Contact
            </a>
            <Link
              to="/faqs"
              onClick={() => {
                setIsOpen(false);
                scrollToTop();
              }}
              className="block hover:text-tan transition-colors"
            >
              FAQs
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
