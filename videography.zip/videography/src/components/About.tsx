import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { Award, Users, Target, Heart } from 'lucide-react';

export default function About() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation();
  const { ref: storyRef, isVisible: storyVisible } = useScrollAnimation();
  const { ref: valuesRef, isVisible: valuesVisible } = useScrollAnimation();

  return (
    <div className="bg-soft-linen pt-20 md:pt-28">
      {/* Hero Section */}
      <section
        ref={headerRef as React.RefObject<HTMLElement>}
        className={`relative h-[60vh] flex items-center justify-center overflow-hidden transition-all duration-1000 ${
          headerVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=2071)',
            filter: 'brightness(0.4)',
          }}
        />
        <div className="relative z-10 text-center px-4">
          <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl font-bold text-soft-linen mb-4">
            About Nazaara
          </h1>
          <p className="text-xl sm:text-2xl text-tan max-w-3xl mx-auto">
            Creating and editing videos that communicate the correct message every time
          </p>
        </div>
      </section>

      {/* Our Story Section */}
      <section
        ref={storyRef as React.RefObject<HTMLElement>}
        className={`py-20 px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          storyVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-heading text-4xl sm:text-5xl font-bold text-stone-brown mb-6">
                The reason we exist.
              </h2>
              <div className="space-y-4 text-stone-brown text-lg leading-relaxed">
                <p>
                  Nazaara is in business for one reason: to help brands grow through strategic
                  video content on social media.
                </p>
                <p>
                  With years of experience in the creative industry, from creating custom artwork to
                  photography, graphic design, website builds, screen printing, and now videography,
                  we understand the power of visual storytelling.
                </p>
                <p>
                  There is no greater power than being able to take an idea or a thought and bring it
                  into reality. Our priority is to create value and build strong, lasting relationships
                  with our clients.
                </p>
                <p>
                  We do this by understanding your vision and bringing that to life through compelling
                  video content that drives results.
                </p>
              </div>
            </div>
            <div className="relative h-[500px] rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=2071"
                alt="Video Production"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section
        ref={valuesRef as React.RefObject<HTMLElement>}
        className={`py-20 px-4 sm:px-6 lg:px-8 bg-stone-brown transition-all duration-1000 ${
          valuesVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="max-w-7xl mx-auto">
          <h2 className="font-heading text-4xl sm:text-5xl font-bold text-soft-linen text-center mb-16">
            What We Stand For
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-tan rounded-full mb-4">
                <Award className="w-8 h-8 text-stone-brown" />
              </div>
              <h3 className="font-heading text-2xl font-bold text-tan mb-3">Excellence</h3>
              <p className="text-soft-linen">
                We deliver exceptional quality in every frame, ensuring your brand stands out.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-tan rounded-full mb-4">
                <Users className="w-8 h-8 text-stone-brown" />
              </div>
              <h3 className="font-heading text-2xl font-bold text-tan mb-3">Partnership</h3>
              <p className="text-soft-linen">
                Your success is our success. We work alongside you as true collaborators.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-tan rounded-full mb-4">
                <Target className="w-8 h-8 text-stone-brown" />
              </div>
              <h3 className="font-heading text-2xl font-bold text-tan mb-3">Strategy</h3>
              <p className="text-soft-linen">
                Every video is crafted with purpose, driving measurable results for your business.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-tan rounded-full mb-4">
                <Heart className="w-8 h-8 text-stone-brown" />
              </div>
              <h3 className="font-heading text-2xl font-bold text-tan mb-3">Passion</h3>
              <p className="text-soft-linen">
                We love what we do, and it shows in every project we undertake.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-heading text-4xl sm:text-5xl font-bold text-stone-brown mb-6">
            Ready to bring your vision to life?
          </h2>
          <p className="text-xl text-stone-brown mb-8">
            Let's create something extraordinary together.
          </p>
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-tan text-black px-8 py-4 text-lg font-semibold hover:bg-stone-brown hover:text-soft-linen transition-all duration-300 rounded shadow-lg hover:shadow-2xl transform hover:scale-105"
          >
            Get in Touch
          </a>
        </div>
      </section>
    </div>
  );
}
