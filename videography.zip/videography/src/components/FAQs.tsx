import { useState } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQ {
  question: string;
  answer: string;
}

const faqs: FAQ[] = [
  {
    question: 'What types of video services do you offer?',
    answer:
      'We specialize in social media video content, including promotional videos, brand stories, product showcases, event coverage, testimonials, and video ads optimized for platforms like Instagram, TikTok, YouTube, and Facebook.',
  },
  {
    question: 'How long does it take to complete a video project?',
    answer:
      'Turnaround time depends on the project scope. Simple social media videos typically take 5-7 business days, while more complex projects like brand films can take 2-4 weeks. We provide a detailed timeline during our discovery call.',
  },
  {
    question: 'What is your pricing structure?',
    answer:
      'Our pricing is project-based and depends on factors like video length, complexity, number of revisions, and deliverables. We offer custom packages tailored to your needs and budget. Contact us for a personalized quote.',
  },
  {
    question: 'Do you provide video editing services only, or do you also film?',
    answer:
      'We offer both! We can handle the entire process from concept development and filming to editing and post-production. If you already have footage, we also provide editing-only services.',
  },
  {
    question: 'What equipment do you use?',
    answer:
      'We use professional-grade cameras, lighting, and audio equipment to ensure the highest quality output. Our gear is regularly updated to stay current with industry standards and deliver cinematic results.',
  },
  {
    question: 'Can you help with video strategy for social media?',
    answer:
      'Absolutely! We don\'t just create videos; we help you develop a strategic approach to video content that aligns with your brand goals and resonates with your target audience across different platforms.',
  },
  {
    question: 'How many revisions are included?',
    answer:
      'Most packages include 2-3 rounds of revisions. Additional revisions can be accommodated for an extra fee. We work closely with you throughout the process to minimize the need for extensive changes.',
  },
  {
    question: 'What do I need to provide before starting a project?',
    answer:
      'We typically need your brand guidelines, logo files, any existing footage or assets, key messaging points, and your goals for the video. We\'ll discuss all requirements during our initial discovery call.',
  },
  {
    question: 'Do you offer packages for ongoing video content?',
    answer:
      'Yes! We offer monthly retainer packages for businesses that need consistent video content for social media. This is perfect for building a strong video presence and maintaining audience engagement.',
  },
  {
    question: 'What file formats will I receive?',
    answer:
      'We deliver videos in formats optimized for your intended platforms (MP4, MOV, etc.) and can provide various resolutions and aspect ratios (16:9, 9:16, 1:1) to suit different social media channels.',
  },
  {
    question: 'Do you work with clients remotely?',
    answer:
      'Yes! We work with clients both locally and remotely. For remote projects, we can coordinate filming through local crews or work with footage you provide. Our editing and post-production services are fully remote-friendly.',
  },
  {
    question: 'What makes Reps Media different from other videography services?',
    answer:
      'We combine creative excellence with strategic thinking. Every video we create is designed not just to look good, but to deliver measurable results for your business. We focus on authentic storytelling that connects with your audience.',
  },
];

export default function FAQs() {
  const { ref, isVisible } = useScrollAnimation();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="bg-soft-linen min-h-screen pt-20 md:pt-28">
      {/* Hero Section */}
      <section className="bg-stone-brown py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl font-bold text-soft-linen mb-6">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-tan">
            Everything you need to know about working with Reps Media
          </p>
        </div>
      </section>

      {/* FAQs Section */}
      <section
        ref={ref as React.RefObject<HTMLElement>}
        className={`py-20 px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="max-w-4xl mx-auto">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white rounded-lg shadow-md overflow-hidden border border-tan/20"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-tan/5 transition-colors"
                >
                  <h3 className="font-heading text-lg sm:text-xl font-semibold text-stone-brown pr-4">
                    {faq.question}
                  </h3>
                  {openIndex === index ? (
                    <ChevronUp className="w-6 h-6 text-tan flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-tan flex-shrink-0" />
                  )}
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <div className="px-6 pb-5 text-stone-brown leading-relaxed">
                    {faq.answer}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-stone-brown">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading text-4xl sm:text-5xl font-bold text-soft-linen mb-6">
            Still have questions?
          </h2>
          <p className="text-xl text-tan mb-8">
            We're here to help at Nazaara. Reach out and let's discuss your project.
          </p>
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-tan text-black px-8 py-4 text-lg font-semibold hover:bg-soft-linen transition-all duration-300 rounded shadow-lg hover:shadow-2xl transform hover:scale-105"
          >
            Contact Us
          </a>
        </div>
      </section>
    </div>
  );
}
