import { memo } from 'react';
import { Phone } from 'lucide-react';

function FloatingCTA() {
  return (
    <div className="fixed right-0 top-1/2 -translate-y-1/2 z-50">
      <a
        href="https://docs.google.com/forms/d/e/1FAIpQLScVIBg8Eu-ipj1E1y8amThBwgf-lP_-K76SkUSquuXQ_MvY-Q/viewform?usp=header"
        target="_blank"
        rel="noopener noreferrer"
        className="bg-tan text-black px-3 py-12 font-semibold hover:bg-stone-brown hover:text-soft-linen transition-all duration-300 shadow-xl hover:shadow-2xl flex items-center justify-center gap-2 writing-mode-vertical transform hover:scale-105 rounded-full"
      >
        <Phone className="w-4 h-4 rotate-90" />
        <span className="text-sm tracking-wider font-bold" style={{ writingMode: 'vertical-rl' }}>
          Get in touch
        </span>
      </a>
    </div>
  );
}

export default memo(FloatingCTA);
