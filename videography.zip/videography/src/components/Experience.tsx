import { useScrollAnimation } from '../hooks/useScrollAnimation';

export default function Experience() {
  const section1 = useScrollAnimation();
  const section2 = useScrollAnimation();
  const section3 = useScrollAnimation();

  return (
    <section className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-soft-linen overflow-x-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12 sm:mb-16 md:mb-24">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-3 sm:mb-4">
            The experience
          </h2>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-stone-brown px-4">
            Here is what you can expect from us - every time
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-center mb-16 sm:mb-24">
          <div
            ref={section1.ref as React.RefObject<HTMLDivElement>}
            className={`order-2 lg:order-1 transition-all duration-1000 ${
              section1.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'
            }`}
          >
            <img
              src="https://images.pexels.com/photos/7648047/pexels-photo-7648047.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Every project gets the same energy"
              className="w-full rounded-2xl shadow-lg"
            />
          </div>
          <div className="order-1 lg:order-2">
            <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
              Every project gets the same energy
            </h3>
            <p className="text-sm sm:text-base md:text-lg leading-relaxed mb-3 sm:mb-4">
              Whether it's a casual gym shoot or a full day production - every
              project big or small gets the same level of dedication and
              creative direction.
            </p>
            <p className="text-sm sm:text-base md:text-lg leading-relaxed">
              Because we are passionate about what we do.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-center mb-16 sm:mb-24">
          <div>
            <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
              Super-easy process from the start
            </h3>
            <p className="text-sm sm:text-base md:text-lg leading-relaxed">
              From discovery call to delivering your content, the whole process
              has been carefully designed to be streamlined and pain-free.
            </p>
          </div>
          <div
            ref={section2.ref as React.RefObject<HTMLDivElement>}
            className={`transition-all duration-1000 ${
              section2.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
            }`}
          >
            <img
              src="https://images.pexels.com/photos/2608519/pexels-photo-2608519.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Super-easy process"
              className="w-full rounded-2xl shadow-lg"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-center">
          <div
            ref={section3.ref as React.RefObject<HTMLDivElement>}
            className={`order-2 lg:order-1 transition-all duration-1000 ${
              section3.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'
            }`}
          >
            <img
              src="https://images.pexels.com/photos/3760790/pexels-photo-3760790.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Content that gets results"
              className="w-full rounded-2xl shadow-lg"
            />
          </div>
          <div className="order-1 lg:order-2">
            <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
              Content that actually gets results
            </h3>
            <p className="text-sm sm:text-base md:text-lg leading-relaxed">
              Don't spend hours creating the perfect reel to only get 12 likes.
              We have strategies in place that can help drive the results you
              want.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
