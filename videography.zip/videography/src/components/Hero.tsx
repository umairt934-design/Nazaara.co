import { useScrollAnimation } from '../hooks/useScrollAnimation';

export default function Hero() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section
      ref={ref as React.RefObject<HTMLElement>}
      id="home"
      className={`relative min-h-screen flex items-center justify-center bg-black text-soft-linen pt-16 mt-10 transition-all duration-1000 overflow-x-hidden ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
    >
      <div
        className="absolute inset-0 bg-cover bg-center opacity-60"
        style={{
          backgroundImage:
            'url(https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-3xl xs:text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-4 sm:mb-6">
          Videos are only good
          <br />
          for one thing.
        </h1>

        <p className="text-xl xs:text-2xl sm:text-3xl md:text-4xl font-semibold mb-6 sm:mb-8">
          Delivering a message.
        </p>

        <p className="text-sm xs:text-base sm:text-lg md:text-xl max-w-2xl mx-auto mb-8 sm:mb-10 leading-relaxed px-2">
          We create and edit videos that communicate the correct message every
          time. Let us focus on the creative stuff, while you do what you do
          best.
        </p>

        <button className="bg-tan text-black px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold hover:bg-stone-brown hover:text-soft-linen transition-all duration-300 rounded">
          Book a Discovery Call
        </button>

        <div className="mt-12 sm:mt-16 pt-12 sm:pt-16 border-t border-stone-brown">
          <p className="text-xs sm:text-sm md:text-base italic mb-4 max-w-3xl mx-auto leading-relaxed px-2">
            "Brogan's work exceeded expectations, he understood what was needed
            for our business & delivered more than expected. Could not recommend
            him enough"
          </p>
          <p className="text-xs sm:text-sm font-semibold">
            Steven Komene, Director | The Early Ones
          </p>
        </div>

        <div className="mt-8 sm:mt-12 flex items-center justify-center gap-2">
          <div className="flex items-center gap-1 sm:gap-2">
            <span className="text-blue-500 text-lg sm:text-2xl font-bold">G</span>
            <span className="text-red-500 text-lg sm:text-2xl font-bold">o</span>
            <span className="text-yellow-500 text-lg sm:text-2xl font-bold">o</span>
            <span className="text-blue-500 text-lg sm:text-2xl font-bold">g</span>
            <span className="text-green-500 text-lg sm:text-2xl font-bold">l</span>
            <span className="text-red-500 text-lg sm:text-2xl font-bold">e</span>
          </div>
          <div className="flex text-yellow-400 text-sm sm:text-base">
            <span>★</span>
            <span>★</span>
            <span>★</span>
            <span>★</span>
            <span>★</span>
          </div>
        </div>
        <p className="text-xs sm:text-sm mt-2">Trusted by 100+ clients</p>

        <div className="mt-8 sm:mt-12 flex flex-wrap items-center justify-center gap-3 sm:gap-4 md:gap-6 lg:gap-8 opacity-70 px-2">
          <div className="text-xs sm:text-sm font-semibold">VOICE OF MOAMA</div>
          <div className="text-xs sm:text-sm font-semibold">LSXD</div>
          <div className="text-xs sm:text-sm font-semibold">LOCKER COLLECTIVE</div>
          <div className="text-xs sm:text-sm font-semibold">THE POWER HUB</div>
          <div className="text-xs sm:text-sm font-semibold">THE EARLY ONES</div>
          <div className="text-xs sm:text-sm font-semibold">ASTA</div>
        </div>
      </div>
    </section>
  );
}
